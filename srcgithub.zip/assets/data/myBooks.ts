import { BooksInfo } from '../../app/bookinfo';

export const MYBOOKS: BooksInfo[] =
[
    {bname: 'City of girls', bauthor: 'Elizabeth Gilbert' , bgenre: 'Romance novel', byear: '2019', bpic: "assets/Images/img1.jpg"},
    {bname: 'The Old drift', bauthor: 'Namwali Serpell' , bgenre: 'Historical Fiction', byear: '2017', bpic:"assets/Images/img2.jpg"},
    {bname: 'Disappearing Earth', bauthor: 'Julia Phillips' , bgenre: 'Thriller, Mystery', byear: '2018', bpic:"assets/Images/img3.jpg"},
    {bname: 'The Testaments', bauthor: 'Margaret Atwood' , bgenre: 'Science Fiction', byear: '2019', bpic:"assets/Images/img4.jpg"}
]